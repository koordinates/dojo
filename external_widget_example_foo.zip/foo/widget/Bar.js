dojo.provide("foo.widget.Bar");

dojo.widget.defineWidget("foo.widget.Bar", dojo.widget.HtmlWidget, {
	fillInTemplate: function() {
		this.domNode.innerHTML = 'not fubared';
	}
});