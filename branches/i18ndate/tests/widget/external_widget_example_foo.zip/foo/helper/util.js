dojo.provide("foo.helper.util");

foo.helper.util.getUtilMessage = function(){
	return "foo.helper.util loaded successfully";
}