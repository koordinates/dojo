dojo.provide("foo.manifest");
dojo.require("dojo.string.extras");

dojo.registerNamespaceResolver("foo", 
	function(name) {
		return "foo.widget."+dojo.string.capitalize(name);
	}
);
