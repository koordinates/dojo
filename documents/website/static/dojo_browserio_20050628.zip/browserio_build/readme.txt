A few clarifying notes:

* Dojo uses XmlHttpRequest, so it will not work unless you run it inside a web server.  (The web server can be running locally on your machine.) For example, you may wonder how the javascript snippet inside "test_BrowserIO_data.txt" is loaded for evaluation -- it's done with XmlHttpRequest.

* The presence of "blank.html" may seem mysterious at first glance -- it is there as part of a workaround to get back-button management to work cross-browser.